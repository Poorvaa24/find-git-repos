<template>
  <div id="app" class="small-container">
    <h1>Repository Search</h1>

    <repository-form />
  </div>
</template>

<script>
  import RepositoryForm from '@/components/RepositoryForm.vue'
  // app Vue instance
  const app = {
    name: 'app',
    components: {
      RepositoryForm
    },
    // app initial state
    data: () => {
      return {
      }
    }
  }

  export default app
</script>

<style>
  button {
    background: #009435;
    border: 1px solid #009435;
  }
  button:hover,
  button:active,
  button:focus {
    background: #32a95d;
    border: 1px solid #32a95d;
  }
  .small-container {
    max-width: 1200px;
  }
  [v-cloak] { display: none; }
</style>
