<template>
  <div id="repository-form">

    <form v-on:submit.prevent="getfiles">
      <label>Enter the keyword</label>
      <input type="text" v-model="keyword" placeholder="Enter keyword" required />
      <br>
      <button>Search Repositories</button>
    </form>

    <br>
    <br>

    <label>List of Repositories</label>
    <br>

    <table>
      <thead>
      <tr>
        <th>Avatar</th>
        <th>Repo Name</th>
        <th>Full Name</th>
        <th>Github Url</th>
        <th> </th>
        <th> </th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="repo in repos" :key="repo.id">
        <td><img v-bind:src = repo.avatar width="50" height="50" > </td>
        <td>{{repo.name}} </td>
        <td>{{repo.fname}}</td>
        <td><a v-bind:href = repo.repo_url target="_blank">{{repo.repo_url}}</a></td>
<!--        <td><button type = "button" @click="onAddBookmark(repo)">Add Bookmark</button></td>-->
<!--        <td><button type = "button" @click="onRemoveBookmark(repo)"> Remove Bookmark </button></td>-->

      </tr>
      </tbody>
    </table>


  </div>
</template>

<script>
  // eslint-disable-next-line no-unused-vars
  import axios from 'axios';
  export default {
    name: 'repository-form',
    data() {
      return {
        repos: [],
        keyword: '',
      }
    },
     methods: {
       getfiles()
       {
         const path = 'http://127.0.0.1:8080/repos?keyword='+this.keyword;
         console.log(path);
         axios.get(path).then((res) => {
           console.log(res.data);
           this.repos = res.data.repos;
         })
                 .catch((error) => {
                   console.error(error);
                 })
       },

       onRemoveBookmark(repo)
       {
         var html_url = repo.repo_url;
         console.log(html_url);


       },

       onAddBookmark(repo)
       {
         var  html_url = repo.repo_url;
         console.log(html_url);

         if('sidebar' in window && 'addPanel' in window.sidebar)
         {
           window.sidebar.addPanel(repo.repo_url, repo.name, "");
         }
         else if(window.external && ('AddFavorite' in window.external))
         {
           window.external.AddFavorite(repo.repo_url, repo.name);
         }
         else
         {
           alert('Press ' + (navigator.userAgent.toLowerCase().indexOf('mac') != -1 ? 'Command/Cmd' : 'CTRL') + ' + D to bookmark this page.');
         }

       },

     },

    created() {
    }
  }
</script>

<style scoped>
  form {
    margin-bottom: 2rem;
  }
</style>
