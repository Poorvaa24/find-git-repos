 <template>
      <div id="repository-form">

        <form v-on:submit.prevent="getfiles">
          <label>Enter the keyword</label>
          <input type="text" v-model="keyword" placeholder="Enter keyword" required />
          <br>
          <button>Search Repositories</button>

        </form>

        <label v-if="this.repos.length > 0">List of Repositories</label>
        <br>

        <table>
          <thead>
          <tr>
            <th  v-if="this.repos.length > 0">Avatar</th>
            <th  v-if="this.repos.length > 0">Repo Name</th>
            <th  v-if="this.repos.length > 0">Full Name</th>
            <th  v-if="this.repos.length > 0">Github Url</th>
            <th> </th>
            <th> </th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="repo in repos" :key="repo.id" >
            <td v-if="repo.isBookmarked > 0" style="background: darkgrey"><img v-bind:src = repo.avatar width="50" height="50" > </td>
            <td v-if="repo.isBookmarked < 1" style="background: white"><img v-bind:src = repo.avatar width="50" height="50" > </td>
            <td v-if="repo.isBookmarked > 0" style="background: darkgrey">{{repo.name}} </td>
            <td v-if="repo.isBookmarked < 1" style="background: white">{{repo.name}} </td>
            <td v-if="repo.isBookmarked > 0" style="background: darkgrey">{{repo.fname}}</td>
            <td v-if="repo.isBookmarked < 1" style="background: white">{{repo.fname}}</td>
            <td v-if="repo.isBookmarked > 0" style="background: darkgrey"><a v-bind:href = repo.repo_url target="_blank">{{repo.repo_url}}</a></td>
            <td v-if="repo.isBookmarked < 1" style="background: white"><a v-bind:href = repo.repo_url target="_blank">{{repo.repo_url}}</a></td>
                    <td v-if="repo.isBookmarked > 0" style="background: darkgrey"><button type = "button" @click="onAddBookmark(repo)">Add Bookmark</button></td>
                    <td v-if="repo.isBookmarked < 1" style="background: white"><button type = "button" @click="onAddBookmark(repo)">Add Bookmark</button></td>
                    <td v-if="repo.isBookmarked > 0" style="background: darkgrey"><button type = "button" @click="onRemoveBookmark(repo)"> Remove Bookmark </button></td>
                    <td v-if="repo.isBookmarked < 1" style="background: white"><button type = "button" @click="onRemoveBookmark(repo)"> Remove Bookmark </button></td>
                    <td v-if="repo.isBookmarked > 0" style="background: darkgrey">Already Bookmarked</td>

          </tr>
          </tbody>

          <br>
          <button id="b2" v-on:click="getbRepos" >Get Bookmarked Repositories </button>
          <br>

        </table>
        <table id="bookmarkTable" >
          <thead>
          <tr>
            <th v-if="this.bookmarked_repos.length > 0">List of Bookmarked Repositories</th>
            <th> </th>
            <th> </th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="repo in bookmarked_repos" :key="repo.id">
            <td><a v-bind:href = repo.url target="_blank">{{repo.url}}</a></td>
          </tr>
          </tbody>
        </table>

      </div>
    </template>

<script>
  // eslint-disable-next-line no-unused-vars
  import axios from 'axios';
  export default {
    name: 'repository-form',
    data() {
      return {
        repos: [],
        keyword: '',
        bookmarked_repos: [],
      }
    },
     methods: {
       getfiles()
       {
         const path = 'http://127.0.0.1:8080/repos?keyword='+this.keyword;
         console.log(path);
         axios.get(path).then((res) => {
           console.log(res.data);
           this.repos = res.data.repos;
         })
                 .catch((error) => {
                   console.error(error);
                 })
       },

       onRemoveBookmark(repo)
       {
         var html_url = repo.repo_url;
         console.log(html_url);

         const path = 'http://localhost:8080/repos/bookmarks?url='+html_url;
         console.log(path);
         axios.delete(path).then((res) => {
           console.log(res.data);
           alert(res.data.result);

         })
                 .catch((error) => {
                   console.error(error);
                 })

       },

       onAddBookmark(repo)
       {
         var html_url = repo.repo_url;
         console.log(html_url);

         const path = 'http://localhost:8080/repos/bookmarks?url='+html_url;
         console.log(path);
         axios.post(path).then((res) => {
           console.log(res.data);
           alert(res.data.result);

         })
                 .catch((error) => {
                   console.error(error);
                 })


       },
       getbRepos()
       {
         const path = 'http://127.0.0.1:8080/repos/bookmarks';
         console.log(path);
         axios.get(path).then((res) => {
           console.log(res.data);
           this.bookmarked_repos = res.data.bookmarks;
         })
                 .catch((error) => {
                   console.error(error);
                 })
       },

     },

    created() {
    }
  }
</script>

<style scoped>
  form {
    margin-bottom: 2rem;
  }
  .mark-row {
    bgcolor: "#FF0000";
  }
</style>
